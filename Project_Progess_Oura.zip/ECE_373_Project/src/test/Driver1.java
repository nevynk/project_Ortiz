package test;

import system.forms.*;
import system.hardware.*;
import system.information.*;
import system.people.*;

public class Driver1 {
	public static void main(String[] args) {
		Person p1 = new Person();
		Person p2 = new Person();
		Person p3 = new Person();
		Person p4 = new Person();
		Person p5 = new Person();
		Equipment e1 = new Equipment();
		Equipment e2 = new Equipment();
		Roster ro1 = new Roster();
		Inventory i1 = new Inventory();
		
		p1.setName("Kara Danvers");
		p1.setUserID(01);
		p2.setName("Lena Luthor");
		p2.setUserID(02);
		p3.setName("Alex Danvers");
		p3.setUserID(03);
		p4.setName("Maggie Sawyer");
		p4.setUserID(04);
		p5.setName("Winn Schott");
		p5.setUserID(05);

		e1.setSerialNumber("E33642RT456");
		e1.setName("Bananas");
		e2.setName("Josh");
		e2.setSerialNumber("R3375FT965");
		e1.setBrand("Garlic");
		e1.setModel("Highlighter");
		e1.setDateInstalled(6122017);
		e1.setIDNum(5);
		
		e2.setBrand("Root beer");
		e2.setDateInstalled(11242015);
		e2.setIDNum(2);
		e2.setModel("Knife");
		
		Location l1 = new Location();
		l1.setAddress("NW");
		l1.setGPS(56.9);
		
		Location l2 = new Location();
		l2.setAddress("SW");
		l2.setGPS(90.5);
		
		e1.setLocation(l1);
		e2.setLocation(l2);
		
		ro1.addPerson(p2);
		ro1.addPerson(p1);
		ro1.addPerson(p5);
		ro1.addPerson(p3);
		ro1.addPerson(p4);
		
		i1.addEquipment(e1);
		i1.addEquipment(e2);
		i1.setTotItems(2);
		i1.sortEquipment();
		i1.addEquipment(e1);
		i1.removeEquipment(e1);
		i1.removeEquipment(e1);
		Invoice in1 = new Invoice();
		in1.setMinDue(50.8);
		in1.setTotalDue(620);
		in1.setDueDate(1012017);
		in1.setPerson(p1);
	
		in1.generateInvoice();
		i1.addPerson(p1);
		i1.addPerson(p2);
		i1.addPerson(p5);
		i1.addPerson(p2);
		i1.removePerson(p5);
		i1.removePerson(p5);
		
		i1.sortByPeople();
		
		System.out.println("Inventory people");
		for (int i = 0; i < i1.getPeople().size(); i++) {
			System.out.println(i1.getPeople().get(i).getName());
		}


		
		Quote q1 = new Quote();
		
		q1.setPerson(p5);
		q1.setAvailableSpeedDown(34);
		q1.setAvailableSpeedUp(56);
		q1.setPrice(56.79);
		q1.generateQuote();
		
		System.out.println(ro1.getTotalPeople());
		ro1.sortPeople();
		
		ro1.generateRoster();
		i1.generateInventoryReport();
	}
}
