package system.hardware;

import system.information.Location;

public class Equipment {
	private String name;
	private String model;
	private String brand;
	private String serialNumber;
	private long dateInstalled;
	private int iDNum;
	private Location location;
	
	public String getName() {
		return this.name;
	}

	public String getModel() {
		return this.model;
	}

	public String getBrand() {
		return this.brand;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public long getDateInstalled() {
		return this.dateInstalled;
	}

	public int getIDNum() {
		return this.iDNum;
	}
	
	public Location getLocation() {
		return this.location;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public void setDateInstalled(long dateInstalled) {
		this.dateInstalled = dateInstalled;
	}

	public void setIDNum(int iDNum) {
		this.iDNum = iDNum;
	}
	
	public void setLocation(Location location) {
		this.location = location;
	}

}
